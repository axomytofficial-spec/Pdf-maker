PDF Maker - Android project (Capacitor)

You need: Node.js 20+ and Android Studio installed.

1. Change the app id (optional but do it before publishing):
   open capacitor.config.json and edit "appId" (example: com.yourname.pdfmaker).
2. In this folder run:   node setup.js
   (installs packages, creates the android folder, adds camera permission, syncs)
3. Run:                  npx cap open android
4. In Android Studio: wait for Gradle sync, plug in your phone (USB debugging on)
   and press Run, or choose Build > Build APK(s).
   Debug APK location: android/app/build/outputs/apk/debug/app-debug.apk

After editing www/index.html run:  npx cap sync android

For Google Play you need a signed release build (Build > Generate Signed Bundle / APK),
an app icon, and a privacy policy URL.

Note: Word to PDF, Excel to PDF and PDF to Word show "Coming soon" (no server yet).

BUILD WITHOUT ANDROID STUDIO (GitHub Actions)
1. Create a new GitHub repo and upload everything in this folder
   (keep the hidden .github folder).
2. Open the repo > Actions > "Build APK" > Run workflow
   (it also runs on every push to main).
3. When it finishes, open the run and download "PDF-Maker-debug-apk" under Artifacts.
   Unzip it to get app-debug.apk and install it on your phone.

ADS (Google AdMob)
- The app ships with Google TEST ads. To earn money: create an AdMob account, add the app,
  then put your App ID in setup.js (ADMOB_APP_ID) and your Banner/Interstitial unit ids in www/index.html (ADS),
  and set ADS.test=false. Never click your own live ads.
- Google Play: in Play Console > App content, declare that the app contains ads and fill the Data safety form.

PREMIUM (remove ads): Yearly Rs 49 and Lifetime Rs 99
- Play Console > Monetize > In-app products: create  remove_ads_lifetime  (one-time, Rs 99, Activate).
- Play Console > Monetize > Subscriptions: create  remove_ads_yearly  with a base plan id  yearly  (auto-renewing, billing period 1 year, Rs 49, Activate).
- To use other ids, change LIFE_ID / YEAR_ID / YEAR_PLAN in www/index.html.
- Purchases only work in a build installed from Google Play (Internal testing + add yourself as license tester).
