// One-time setup: node setup.js
const { execSync } = require('child_process');
const fs = require('fs');
const run = (c) => { console.log('\n> ' + c); execSync(c, { stdio: 'inherit' }); };

run('npm install');
if (!fs.existsSync('android')) run('npx cap add android');

const mf = 'android/app/src/main/AndroidManifest.xml';
let x = fs.readFileSync(mf, 'utf8');
if (!x.includes('android.permission.CAMERA')) {
  const perms =
    '<uses-permission android:name="android.permission.CAMERA" />\n' +
    '    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="32" />\n' +
    '    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />\n' +
    '    <application android:requestLegacyExternalStorage="true"';
  x = x.replace('<application', perms);
  fs.writeFileSync(mf, x);
  console.log('Added camera and storage permissions');
}
// ---- AdMob (ads) ----
// Test app id below is Google's sample id. Replace with YOUR AdMob App ID (ca-app-pub-XXXX~YYYY) before publishing.
const ADMOB_APP_ID = 'ca-app-pub-6383993172311136~5062480675';
x = fs.readFileSync(mf, 'utf8');
if (!x.includes('com.google.android.gms.ads.APPLICATION_ID')) {
  x = x.replace('</application>',
    '    <meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="' + ADMOB_APP_ID + '"/>\n    </application>');
}
if (!x.includes('com.google.android.gms.permission.AD_ID')) {
  x = x.replace('<application', '<uses-permission android:name="com.google.android.gms.permission.AD_ID" />\n    <application');
}
fs.writeFileSync(mf, x);
console.log('Added AdMob app id and ad permission');
// ---- App icon (launcher) ----
if (fs.existsSync('icon-res')) {
  fs.cpSync('icon-res', 'android/app/src/main/res', { recursive: true, force: true });
  console.log('Installed app icon');
}
run('npx cap sync android');
console.log('\nDone. Now run: npx cap open android   (then Build > Build APK(s) in Android Studio)');
