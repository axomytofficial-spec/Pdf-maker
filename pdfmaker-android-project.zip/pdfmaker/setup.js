// One-time setup: node setup.js
const { execSync } = require('child_process');
const fs = require('fs');
const run = (c) => { console.log('\n> ' + c); execSync(c, { stdio: 'inherit' }); };

run('npm install');
if (!fs.existsSync('android')) run('npx cap add android');

const mf = 'android/app/src/main/AndroidManifest.xml';
let x = fs.readFileSync(mf, 'utf8');
if (!x.includes('android.permission.CAMERA')) {
  x = x.replace('<application', '<uses-permission android:name="android.permission.CAMERA" />\n    <application');
  fs.writeFileSync(mf, x);
  console.log('Added CAMERA permission');
}
run('npx cap sync android');
console.log('\nDone. Now run: npx cap open android   (then Build > Build APK(s) in Android Studio)');
