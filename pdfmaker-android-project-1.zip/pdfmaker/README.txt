PDF Maker - Android project (Capacitor)

You need: Node.js 20+ and Android Studio installed.

1. Change the app id (optional but do it before publishing):
   open capacitor.config.json and edit "appId" (example: com.yourname.pdfmaker).
2. In this folder run:   node setup.js
   (installs packages, creates the android folder, adds camera permission, syncs)
3. Run:                  npx cap open android
4. In Android Studio: wait for Gradle sync, plug in your phone (USB debugging on)
   and press Run, or choose Build > Build APK(s).
   Debug APK location: android/app/build/outputs/apk/debug/app-debug.apk

After editing www/index.html run:  npx cap sync android

For Google Play you need a signed release build (Build > Generate Signed Bundle / APK),
an app icon, and a privacy policy URL.

Note: Word to PDF, Excel to PDF and PDF to Word show "Coming soon" (no server yet).

BUILD WITHOUT ANDROID STUDIO (GitHub Actions)
1. Create a new GitHub repo and upload everything in this folder
   (keep the hidden .github folder).
2. Open the repo > Actions > "Build APK" > Run workflow
   (it also runs on every push to main).
3. When it finishes, open the run and download "PDF-Maker-debug-apk" under Artifacts.
   Unzip it to get app-debug.apk and install it on your phone.
