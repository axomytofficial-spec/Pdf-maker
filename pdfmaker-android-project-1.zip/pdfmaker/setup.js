// One-time setup: node setup.js
const { execSync } = require('child_process');
const fs = require('fs');
const run = (c) => { console.log('\n> ' + c); execSync(c, { stdio: 'inherit' }); };

run('npm install');
if (!fs.existsSync('android')) run('npx cap add android');

const mf = 'android/app/src/main/AndroidManifest.xml';
let x = fs.readFileSync(mf, 'utf8');
if (!x.includes('android.permission.CAMERA')) {
  const perms =
    '<uses-permission android:name="android.permission.CAMERA" />\n' +
    '    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="32" />\n' +
    '    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />\n' +
    '    <application android:requestLegacyExternalStorage="true"';
  x = x.replace('<application', perms);
  fs.writeFileSync(mf, x);
  console.log('Added camera and storage permissions');
}
run('npx cap sync android');
console.log('\nDone. Now run: npx cap open android   (then Build > Build APK(s) in Android Studio)');
